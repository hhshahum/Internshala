# -*- coding: utf-8 -*-
"""
Created on Sat May  4 01:32:24 2019

@author: harsh
"""

from datetime import datetime
import os
import pytz
import requests
import math
API_KEY = '33abce5b9928729a4b13f4f99da254b0'
API_URL = ('http://api.openweathermap.org/data/2.5/weather?q={}&mode=json&units=metric&appid={}')
def query_api(city):
    try:
        print(API_URL.format(city, API_KEY))
        data = requests.get(API_URL.format(city, API_KEY)).json()
    except Exception as exc:
        print(exc)
        data = None
    return data